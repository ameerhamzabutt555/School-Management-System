from django.db import models

class teacher_contact(models.Model):
    teacher_name=models.CharField(max_length=100)
    teacher_Number=models.CharField(max_length=100)
    teacher_address=models.CharField(max_length=100)


class new_admission(models.Model):
    student_class_name=models.CharField(max_length=100)
    student_name=models.CharField(max_length=100)
    student_roll_number=models.CharField(max_length=100)
    student_father_name=models.CharField(max_length=100)
    student_contact = models.CharField(max_length=100,unique=True)

    def __str__(self):
        return self.student_contact



class fee(models.Model):
    contact = models.CharField(max_length=100,default=None)
    fees_of_month = models.CharField(max_length=100,default=None)
    submit_date=models.DateTimeField(default=None)
    fees_amount = models.CharField(max_length=100,default=None)

    def __str__(self):
        return f"{self.contact} {self.fees_of_month}"
