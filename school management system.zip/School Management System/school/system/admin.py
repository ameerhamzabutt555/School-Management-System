from django.contrib import admin
from .models import teacher_contact,new_admission,fee


@admin.register(fee)
class FeeAdmin(admin.ModelAdmin):
    list_display = ['contact','fees_of_month','submit_date','fees_amount']




@admin.register(teacher_contact)
class teacher_contactAdmin(admin.ModelAdmin):
    list_display = ['id','teacher_name','teacher_Number','teacher_address']



@admin.register(new_admission)
class NewAdmissionAdmin(admin.ModelAdmin):
    list_display = ['id','student_class_name','student_name','student_roll_number','student_father_name','student_contact']