from django.urls import path,include
from system import views
urlpatterns = [

    path('gallery/', views.gallery, name='gallery'),
    path('', views.login, name='login'),
    path('register/', views.register, name='register'),
    path('staff/', views.staff, name='staff'),
    path('logout/', views.logout, name='logout'),
    path('students/', views.students, name='students'),
    path('studetail/<int:id>', views.studetail, name='stuDetail'),

]
