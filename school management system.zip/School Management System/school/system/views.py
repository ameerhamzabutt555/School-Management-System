from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib import messages
from .models import teacher_contact,new_admission,fee
def login(request):
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)
            return redirect('students')
        else:
            messages.warning(request, 'Unvalid Username OR Password')
            return redirect('/')
    return render(request,'login.html')


def gallery(request):
    return render(request,'gallery.html')

def studetail(request,id):
    stro = new_admission.objects.get(pk=id)
    why=fee.objects.filter(contact=stro)



    return render(request,'StudentDetail.html',{'detail':stro,'hope':why})




def students(request):

    stu_admission=new_admission.objects.all()

    return render(request, 'students.html', {'well': stu_admission})


def logout(request):
    auth.logout(request)
    messages.info(request, 'Successfully Logout.')
    return redirect('/')

def staff(request):
    tea=teacher_contact.objects.all()
    return render(request,'staff.html',{'tech':tea})


def register(request):

    if request.method=='POST':
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        username=request.POST['username']
        password1=request.POST['password1']
        password2=request.POST['password2']
        if password1!=password2:
            messages.warning(request, 'password not same.')
        elif User.objects.filter(username=username).exists():
            messages.warning(request, 'Username already taken.')
        else:
          user=User.objects.create_user(first_name=first_name,last_name=last_name,username=username,password=password1)
          user.save()
          messages.info(request, 'User Created Successfully.')
          return redirect('/')

    return render(request,'register.html')

